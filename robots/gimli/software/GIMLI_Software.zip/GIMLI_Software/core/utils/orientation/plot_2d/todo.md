# TODO

1. [x] Add a checkbox for show name with points
2. [x] add clicking onto a point highlights the row
3. [x] clicking into the table highlights the point
4. [x] maybe adding bodies with point names
5. [x] lines also from coordinates, not just points
6. [x] reset perspective button
7. [x] show dps (data per second)
8. [x] warning window if there are multiple objects with same id
9. [x] clicking on a point displays some data below
10. [x] Resizing also left and below with mouse